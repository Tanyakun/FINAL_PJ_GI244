﻿using UnityEngine;
using System.Collections;

public class BossController : MonoBehaviour
{
    public float specialMoveCooldown = 30f;
    private float specialMoveTimer;
    private bool isUsingSpecialMove = false;

    public Transform bossBody;
    public float floatHeight = 5f;
    public float floatSpeed = 3f;
    public float tiltAngle = 25f;
    public Transform arena;

    void Start()
    {
        specialMoveTimer = specialMoveCooldown;
    }

    void Update()
    {
        if (!isUsingSpecialMove)
        {
            specialMoveTimer -= Time.deltaTime;
            if (specialMoveTimer <= 0f)
            {
                StartCoroutine(UseSpecialMove());
                specialMoveTimer = specialMoveCooldown;
            }
        }
    }

    IEnumerator UseSpecialMove()
    {
        isUsingSpecialMove = true;

        // ลอยขึ้น
        Vector3 startPos = bossBody.position;
        Vector3 floatPos = startPos + Vector3.up * floatHeight;
        float t = 0;
        while (t < 1f)
        {
            bossBody.position = Vector3.Lerp(startPos, floatPos, t);
            t += Time.deltaTime * floatSpeed;
            yield return null;
        }

        // เอียง Island
        Quaternion startRot = arena.rotation;
        Quaternion tiltRot = Quaternion.Euler(tiltAngle, 0, 0);
        arena.rotation = tiltRot;

        yield return new WaitForSeconds(5f);

        // กลับตรง
        arena.rotation = startRot;

        // ตกลงมา
        t = 0;
        while (t < 1f)
        {
            bossBody.position = Vector3.Lerp(floatPos, startPos, t);
            t += Time.deltaTime * floatSpeed;
            yield return null;
        }

        isUsingSpecialMove = false;
    }
}
